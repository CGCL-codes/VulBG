static int do_quit(Monitor *mon, const QDict *qdict, QObject **ret_data)
{
    exit(0);
    return 0;
}
