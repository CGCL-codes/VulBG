void qemu_cpu_kick(void *env)
{
    return;
}
