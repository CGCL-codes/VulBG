static bool less_than_7(void *opaque, int version_id)
{
    return version_id < 7;
}
