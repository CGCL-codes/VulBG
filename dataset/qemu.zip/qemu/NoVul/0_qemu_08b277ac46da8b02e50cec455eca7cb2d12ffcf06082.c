static bool version_is_5(void *opaque, int version_id)
{
    return version_id == 5;
}
