extern int name ( int , locale_t ) __THROW __exctype_l ( isalnum_l ) ;
 __exctype_l ( isalpha_l )