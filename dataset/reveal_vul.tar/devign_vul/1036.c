extern int name ( int ) __THROW __exctype ( isalnum ) ;
 __exctype ( isalpha ) ;
 __exctype ( iscntrl ) ;
 __exctype ( isdigit )