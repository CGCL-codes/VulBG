static void language_destroy ( hb_language_t * l ) {
 free ( l ) ;
 }