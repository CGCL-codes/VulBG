static void _UTF32Open ( UConverter * cnv , UConverterLoadArgs * pArgs , UErrorCode * pErrorCode ) {
 _UTF32Reset ( cnv , UCNV_RESET_BOTH ) ;
 }