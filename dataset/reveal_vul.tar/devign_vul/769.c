extern int name ( int ) __THROW __exctype ( isalnum ) ;
 __exctype ( isalpha ) ;
 __exctype ( iscntrl ) ;
 __exctype ( isdigit ) ;
 __exctype ( islower ) ;
 __exctype ( isgraph ) ;
 __exctype ( isprint ) ;
 __exctype ( ispunct )