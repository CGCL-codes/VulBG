static const char * _CompoundTextgetName ( const UConverter * cnv ) {
 return "x11-compound-text" ;
 }