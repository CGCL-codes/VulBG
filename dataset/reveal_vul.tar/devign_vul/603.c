void ff_MPV_common_defaults ( MpegEncContext * s ) {
 s -> y_dc_scale_table = s -> c_dc_scale_table = ff_mpeg1_dc_scale_table ;
 s -> chroma_qscale_table = ff_default_chroma_qscale_table ;
 s -> progressive_frame = 1 ;
 s -> progressive_sequence = 1 ;
 s -> picture_structure = PICT_FRAME ;
 s -> coded_picture_number = 0 ;
 s -> picture_number = 0 ;
 s -> input_picture_number = 0 ;
 s -> picture_in_gop_number = 0 ;
 s -> f_code = 1 ;
 s -> b_code = 1 ;
 s -> picture_range_start = 0 ;
 s -> picture_range_end = MAX_PICTURE_COUNT ;
 s -> slice_context_count = 1 ;
 }