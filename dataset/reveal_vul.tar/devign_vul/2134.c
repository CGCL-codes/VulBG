static int qsort_comparison_function_int16 ( const void * a , const void * b ) {
 return * ( const int16_t * ) a - * ( const int16_t * ) b ;
 }