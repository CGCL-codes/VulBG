static __inline __uint32_t __uint32_identity ( __uint32_t __x ) {
 return __x ;
 }